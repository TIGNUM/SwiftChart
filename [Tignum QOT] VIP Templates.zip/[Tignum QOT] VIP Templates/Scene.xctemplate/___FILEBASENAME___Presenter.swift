//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

final class ___VARIABLE_sceneName:identifier___Presenter {

    // MARK: - Properties
    private weak var viewController: ___VARIABLE_sceneName:identifier___ViewControllerInterface?

    // MARK: - Init
    init(viewController: ___VARIABLE_sceneName:identifier___ViewControllerInterface?) {
        self.viewController = viewController
    }
}

// MARK: - ___VARIABLE_sceneName:identifier___Interface
extension ___VARIABLE_sceneName:identifier___Presenter: ___VARIABLE_sceneName:identifier___PresenterInterface {
    func setupView() {
        viewController?.setupView()
    }
}
