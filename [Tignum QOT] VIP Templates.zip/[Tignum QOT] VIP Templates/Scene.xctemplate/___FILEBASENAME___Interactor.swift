//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

final class ___VARIABLE_sceneName:identifier___Interactor {

    // MARK: - Properties
    private lazy var worker = ___VARIABLE_sceneName:identifier___Worker()
    private let presenter: ___VARIABLE_sceneName:identifier___PresenterInterface!

    // MARK: - Init
    init(presenter: ___VARIABLE_sceneName: identifier___PresenterInterface) {
        self.presenter = presenter
    }

    // MARK: - Interactor
    func viewDidLoad() {
        presenter.setupView()
    }
}

// MARK: - ___VARIABLE_sceneName:identifier___InteractorInterface
extension ___VARIABLE_sceneName:identifier___Interactor: ___VARIABLE_sceneName:identifier___InteractorInterface {

}
