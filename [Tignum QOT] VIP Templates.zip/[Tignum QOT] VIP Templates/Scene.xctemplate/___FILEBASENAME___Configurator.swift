//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation
import qot_dal

final class ___VARIABLE_sceneName:identifier___Configurator {
    static func make() -> (___VARIABLE_sceneName:identifier___ViewController) -> Void {
        return { (viewController) in
            let router = ___VARIABLE_sceneName:identifier___Router(viewController: viewController)
            let worker = ___VARIABLE_sceneName:identifier___Worker(contentService: qot_dal.ContentService.main)
            let presenter = ___VARIABLE_sceneName:identifier___Presenter(viewController: viewController)
            let interactor = ___VARIABLE_sceneName:identifier___Interactor(worker: worker, presenter: presenter)
            viewController.interactor = interactor
            viewController.router = router
        }
    }
}
