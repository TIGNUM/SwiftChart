//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

final class ___VARIABLE_sceneName:identifier___Router: DTRouter {}

// MARK: - ___VARIABLE_sceneName:identifier___RouterInterface
extension ___VARIABLE_sceneName:identifier___Router: ___VARIABLE_sceneName:identifier___RouterInterface {}
