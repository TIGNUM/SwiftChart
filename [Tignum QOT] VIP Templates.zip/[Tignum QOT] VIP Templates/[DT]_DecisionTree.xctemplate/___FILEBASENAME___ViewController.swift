//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

final class ___VARIABLE_sceneName:identifier___ViewController: DTViewController {

    // MARK: - Init
    init(configure: Configurator<___VARIABLE_sceneName:identifier___ViewController>) {
        super.init(nibName: R.nib.dtViewController.name, bundle: R.nib.dtViewController.bundle)
        configure(self)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

// MARK: - Private
private extension ___VARIABLE_sceneName:identifier___ViewController {}

// MARK: - ___VARIABLE_sceneName:identifier___ViewControllerInterface
extension ___VARIABLE_sceneName:identifier___ViewController: ___VARIABLE_sceneName:identifier___ViewControllerInterface {}
