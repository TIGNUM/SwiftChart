//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation

protocol ___VARIABLE_sceneName:identifier___ViewControllerInterface: class {}

protocol ___VARIABLE_sceneName:identifier___PresenterInterface {}

protocol ___VARIABLE_sceneName:identifier___InteractorInterface: Interactor {}

protocol ___VARIABLE_sceneName:identifier___RouterInterface {}
