//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation

final class ___VARIABLE_sceneName:identifier___Configurator {
    static func make() -> (___VARIABLE_sceneName:identifier___ViewController) -> Void {
        return { (viewController) in            
            let presenter = ___VARIABLE_sceneName:identifier___Presenter(viewController: viewController)
            let interactor = ___VARIABLE_sceneName:identifier___Interactor(presenter)
            viewController.interactor = interactor            
        }
    }
}
